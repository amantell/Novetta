﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace NovettaExam
{
    public interface IComic
    {
        Task GetRecord();
    }
}
