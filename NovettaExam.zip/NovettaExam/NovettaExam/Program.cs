﻿using System;
using System.Threading.Tasks;

namespace NovettaExam
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hi! Type the name of a comic book publisher at the command prompt. For example, 'XKCD'.");
            Console.WriteLine("Afterwards, hit the 'Enter' key to view a different comic's information from the publisher");
            Console.WriteLine("Type 'Exit' if you want to close the application.");
            GetRecordsAsync().GetAwaiter().GetResult();
        }

        private static async Task GetRecordsAsync()
        {
            bool isOpen = true;
            ComicFactory comicFactory = new ComicFactory();
            IComic comic = null;

            do
            {
                try
                {
                    string value = Console.ReadLine().ToLower().Trim();
                    switch (value)
                    {
                        case "exit":
                            isOpen = false;
                            break;
                        case "xkcd":
                            comic = comicFactory.GetAPI(value);
                            Console.WriteLine("Hit the 'Enter' key now to see results from XKCD.");
                            break;
                        case "":
                            if (comic != null)
                            {
                                var x = comic.GetRecord();
                            }
                            break;
                        default:
                            comic = null;
                            throw new Exception("Hi! Type the name of a comic book publisher at the command prompt. For example, 'XKCD'.");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            } while (isOpen);
        }
    }
}
