﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NovettaExam
{
    class ComicFactory
    {
        public IComic GetAPI(string name)
        {
            IComic comic = null;

            switch (name)
            {
                case "xkcd":
                    comic = new XKCD();
                    break;
                default:
                    throw new Exception("No comic book type was found. Type in a new name.");
            }

            return comic;
        }
    }
}
