﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace NovettaExam
{
    public class XKCD : IComic
    {
        static HttpClient client = new HttpClient();
        private string urlRoot = "https://xkcd.com";
        private int maximum = -1;
        int nextNumber;

        public async Task GetRecord()
        {
            Record result = null;
            Random random = new Random();
            if (maximum == -1) {
                nextNumber = random.Next();
            } else
            {
                nextNumber = random.Next(maximum);
            }

            do
            {
                string url = string.Format("{0}/{1}/info.0.json", urlRoot, nextNumber.ToString());
                result = await GetRecordAsync(url);

                if (result == null)
                {
                    if (maximum == -1)
                    {
                        maximum = nextNumber;
                    }
                    else
                    {
                        if (nextNumber < maximum) maximum = nextNumber;
                        nextNumber = random.Next(maximum);
                    }
                }
                else
                {
                    string title = (result.title == null || result.title.Trim().Length == 0 || result.title == string.Empty) ? result.safe_title : result.title;

                    Console.WriteLine("\n\n-------------------------------------------------------------");
                    Console.WriteLine("-------------------------------------------------------------");
                    Console.WriteLine("XKCD Comic Book Result:");
                    Console.WriteLine("-------------------------------------------------------------");
                    Console.WriteLine("-------------------------------------------------------------");
                    Console.WriteLine("{0}: {1,5}", "Title", title);
                    Console.WriteLine("{0}: {1,5}", "Alt", result.alt);
                    Console.WriteLine("{0}: {1}/{2}", "Date", result.day, result.month);
                    Console.WriteLine("{0}: {1,5}", "Image", result.img);
                    if (result.link != null && result.link != string.Empty && result.link.Trim().Length > 0) Console.WriteLine("{0}: {1,5}", "Link", result.link);
                    if (result.news != null && result.news != string.Empty && result.news.Trim().Length > 0) Console.WriteLine("{0}: {1,5}", "News", result.news);
                    if (result.transcript != null && result.transcript != string.Empty && result.transcript.Trim().Length > 0)
                    {
                        Console.WriteLine("{0}:", "Transcript");
                        Console.WriteLine("----------");
                        Console.WriteLine("{0}", result.transcript);
                    }
                }
            } while (result == null);
        }

        static async Task<Record> GetRecordAsync(string path)
        {
            Record record = null;
            HttpResponseMessage response = await client.GetAsync(path);
            if (response.IsSuccessStatusCode)
            {
                try
                {
                   record = await response.Content.ReadAsAsync<Record>();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return record;
        }
    }
}
